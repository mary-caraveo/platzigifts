<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'platzigift' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ':hG%8Pq|3;+.)wPKPejiV5psTw:7=z?|D?gZ<CrM(j6B60RRSi`i,LVlriY9-R 5');
define('SECURE_AUTH_KEY',  '7s0wP-p-TqeXr47]8F$F1.c*W+ob/l*Boyo 2Da}MEQ-F_E`<+GuI.tWBfWIIWX-');
define('LOGGED_IN_KEY',    '+xh_x1;yJ6 |,<n.*P,K:#86N=;$`+<SNwskLxz{^^rUKL8x<k5ICUf4-3|7|(x>');
define('NONCE_KEY',        'b/0UpY0+h7<q86@)}U+sxi}f4wh4%E:ep1L4mV}r;Z:l~eQ}oni}OE%zNApA)m;e');
define('AUTH_SALT',        'BT^hA2.!Ez-|> 8IwuKP6,;Qy^3!U-.fd!$P4y&IdMo,UUa+FOnwf`7!E 6/O1Y~');
define('SECURE_AUTH_SALT', '3JasoYHqCe(k6E+$sH^BzY8i3~G _<wIN?m#VLhoz[h3fr-t^mX]68Xwr{n/+#,S');
define('LOGGED_IN_SALT',   'O{z3/3u}as-hLh638R0CNd _M{p$r,{eQ,s+Yv8b{w5Sr-g}$HkLS;+z;y&tW$a&');
define('NONCE_SALT',       '~t7(ePZ *_q!SkvMH5|IJH$/:hhYq3;j73)LAXj7,,C5Dbl(Jkg$5JsE(E`xJID~');

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
